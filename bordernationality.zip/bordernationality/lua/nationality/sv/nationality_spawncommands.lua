concommand.Add( "setnat1pos", function()
