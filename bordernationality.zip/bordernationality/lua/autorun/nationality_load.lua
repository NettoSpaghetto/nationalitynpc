if SERVER then
    include ("nationality/sv/nationality_data.lua")
    include ("nationality/sv/nationality_playerspawn.lua")
end